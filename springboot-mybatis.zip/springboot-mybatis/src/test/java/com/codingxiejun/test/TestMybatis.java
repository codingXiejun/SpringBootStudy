package com.codingxiejun.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingxiejun.model.User;
import com.codingxiejun.service.UserService;

@SpringBootTest
@RunWith(SpringRunner.class)
public class TestMybatis {

	@Autowired
	UserService service;
	
	@Test
	public void testSelect() {
		System.out.println(service.selectByPrimaryKey(1).toString());
	}
	
	@Test
	public void testInsert() {
		User user = new User(4,"wangwu","男",35,"重庆");
		System.out.println(service.insert(user));
	}
	
	@Test
	public void testUpdate() {
		User user = new User(4,"wangwu","男",35,"广州");
		System.out.println(service.updateByPrimaryKey(user));
	}
	
	@Test
	public void testDelete() {
		System.out.println(service.deleteByPrimaryKey(4));
	}
}
